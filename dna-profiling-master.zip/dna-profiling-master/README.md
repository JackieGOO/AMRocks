DNA Analysis commands for scientific research

Search through annotated fasta formatted genomes and metagenomes ( protein or DNA) with search terms provided in a user supplied text file. 
Count and identifies protein/gene of interest. 
Search is only as good as the annotation. 




Patches are welcome.

The Software is provided "as is" without warranty of any kind.
